<template>
  <div class="scan">
    <navbar>设备列表</navbar>
    <div class="" >
      <div class="imgContainer" v-if="imgNameArr.length">
        <img v-for="(url,i) in imgNameArr" :src="url" alt="">
      </div>
      
      <span class="lastimg" @click.prevent ="lastimg">
        <img src="../assets/images/index/icon_back.png" alt="">
      </span>
      <span class="nextimg"  @click.prevent="nextimg">
        <img src="../assets/images/index/icon_right.png" alt="">
      </span>
      
      <div class="ffc_sb button">
        <router-link to="/filterStatus"><p>剩余80%，滤芯状态</p></router-link>
        <router-link to="/waterQulity"><p>查看水质</p></router-link>
      </div>
    </div>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  
  export default {
    components: {
      navbar,
    },
    name: 'devicelist',
    data() {
      return {
        imgNameArr: [ '../../src/assets/images/3.jpg', '../../src/assets/images/2.jpg','./static/image/01.jpg',],
        width: null, height: 300, time: 5000, interval: null,$element:null
      }
    },
    mounted() {
      this.carousel();
      this.width = $(window).width();
      this.height = $(window).height();
      $('.imgContainer').css('height',this.height);
    },
    methods: {
      carousel() {
        this.adjustImgStyle();
      },
      adjustImgStyle() {
        $('.imgContainer img').css({
          position: 'absolute',
          top: '0',
          left: '0',
        }).css('left', function (index) {
          return index * this.width;
        });
      },
      lastimg(){
//        console.log(this);
        $('.imgContainer img').css('left', '-=' + this.width);
        let left =  $('.imgContainer img').eq(0).position().left;
          if (left < (this.width * (this.imgNameArr.length - 1) * (-1))) {
            this.adjustImgStyle();
          }
      },
      nextimg(){
        $('.imgContainer img').css({
          position: 'absolute',
          top: '0',
          right: '0',
        }).css('right', function (index) {
          console.log(index)
          // index:当前标签的索引
          return index * this.width;
        });
        $('.imgContainer img').css('right', '-=' + this.width);
        let left =  $('.imgContainer img').eq(0).position().right;
        console.log(left);
        if (left > (this.width * (this.imgNameArr.length - 1) * (-1))) {
          this.adjustImgStyle();
        }
      }
    }
  }
</script>

<style scoped>
  .imgContainer img {
    height: 100%;
    width: 100%;
  }
  
  .imgContainer {
    width:100%;
    position: relative;
    padding: 0;
    overflow: hidden;
  }
  
  .button p {
    color: #333333;
  }
  
  .nextimg {
    cursor: pointer;
    right: 1rem;
    position: fixed;
    top: 60%;
    display: inline-block;
  }
  
  .lastimg {
    left: 1rem;
    display: inline-block;
    position: absolute;
    top: 60%;
    cursor: pointer;
  }
  

  span img {
    display: block;
    width: 0.6rem;
  }
</style>
