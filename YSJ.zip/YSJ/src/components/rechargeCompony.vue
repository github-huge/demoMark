<template>
  <div class="zh">
    <navbar>我要充值</navbar>
    <form method="post" id="recharge_form" onsubmit="recharge_submit()">
      <div class="header">
        <span>充值对象</span>
        <span class="label">  <input id="compony" type="radio" name="aa" value=""><label for="compony">公司</label></span>
        <span class="label"><input id="self" type="radio" name="aa" value=""> <label for="self">自己</label></span>
      </div>
      <group label-width="6em">
        <cell primary="content" value-align="left" title="单位名称" value="long long long longlong longloglong long"></cell>
        <cell title="用户名" value-align="left" value="llonglong"></cell>
        <cell primary="content" value-align="left" title="剩余(天/升)" value="long long long longlong longloglong long"></cell>
        <cell title="设备类型" value-align="left" align-items="flex-start" value="llonglong"></cell>
      </group>
      
      <div class="blank"></div>
      <div class="header">
        <span>充值金额</span>
        <input type="number" name="account" id="chongzhi_money" placeholder="账号" value="蛋糕的">
      </div>
      
      <group title="">
        <x-switch title="是否开票"  v-model="value2" @on-click="onClick"></x-switch>
      </group>
      
      <div class="header">
        <span>发票类型</span>
        <span class="label">  <input id="genetaxi" type="radio" name="taix" value=""><label for="genetaxi">普通</label></span>
        <span class="label"><input id="specltaxi" type="radio" name="taix" value=""> <label for="specltaxi">专票</label></span>
      </div>
      <div class="header">
        <span>发票抬头</span>
        <input type="text" name="account" placeholder="请填写" value="蛋糕的">
      </div>
      <div class="header">
        <span>税号</span>
        <input type="number"  name="account" id="" placeholder="请填写" value="蛋糕的">
      </div>
    </form>
    <div class="blank"></div>
    <group title="选择支付方式">
      <radio :options="radio001">
        <template slot-scope="props" slot="each-item"><!-- use scope="props" when vue < 2.5.0 -->
          <p>
            <img src="http://dn-placeholder.qbox.me/110x110/FF2D55/000" class="vux-radio-icon"> {{ props.label }}
          </p>
        </template>
      </radio>
    </group>
    <x-button class="submit" @click="sub(this)" type="primary">确认充值</x-button>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import {Group, Radio, XButton, Cell, ColorPicker,  XSwitch,} from "vux"
  
  export default {
    components: {
      Group, Radio, Cell, ColorPicker, navbar, XButton,  XSwitch,
    },
    name: 'rechargeCompony',
    data() {
      return {
        value1: true,
        value2: false,
        stringValue: '0',
        colors1: ['#8AEEB1', '#8B8AEE', '#CC68F8'],
        color1: '#FFEF7D',
        radio001: ['专票', '普票'],
        radio003: [{
          icon: 'http://dn-placeholder.qbox.me/110x110/FF2D55/000',
          value: '微信支付',
          key: '001',
        }, {
          icon: 'http://dn-placeholder.qbox.me/110x110/FF2D55/000',
          value: '微信支付',
          key: '002',
        }]
      }
    },
    methods: {
      onClick (newVal, oldVal) {
        console.log(newVal, oldVal)
        this.$vux.loading.show({
          text: 'in processing'
        })
        setTimeout(() => {
          this.$vux.loading.hide()
          this.value2 = newVal
        }, 1000)
      }
    },
  }
</script>

<style scoped>
  input[type='radio']{
    color: #1AAD19;
    background: #1AAD19;
  }
  input[placeholder]{
    font-size:0.8rem;
    line-height:150%;
  }
  .submit {
    height: 2rem;
    margin-top: 2rem;
    width: 90%;
    line-height: 2rem;
    font-size: 0.8rem;
    color: #fff;
  }
  
  .ma-to-20 {
    margin-top: .42667rem;
  }
  
  .header:nth-child(1) {
    border-bottom: 1px solid #dddddd;
  }
  
  .header {
    /*font-size: 0.8rem;*/
    height: 3rem;
    line-height: 3rem;
    padding: 0 0.8rem;
  }
  
  .header input {
    position: relative;
    /*top: 0.1rem;*/
    padding: 0 0.5rem;
    border: none;
  }
  
  .label {
    display: inline-block;
    margin: 0 0.5rem;
  }
</style>
