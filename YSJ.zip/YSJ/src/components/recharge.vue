<template>
  <div class="zh">
   <navbar>我要充值</navbar>
    <form method="post" id="recharge_form" onsubmit="recharge_submit()">
      <div class="header">
        <span>充值对象</span>
         <span class="label">  <input id="compony" type="radio" name="aa" value=""><label for="compony">公司</label></span>
         <span class="label"><input  id="self" type="radio" name="aa" value=""> <label for="self">自己</label></span>
      </div>
      <div class="header">
        <span>充值金额</span>
        <input type="number" name="account" id="chongzhi_money" placeholder="账号" value="">
      </div>
      <div class="blank"></div>
      
      <div class="bawhite ma-to-20">
        <p>充值金额：</p>
        <ul class="clear">
          <li>100 <span style="font-size:0.4rem;">送5元</span></li>
          <li>100 <span>送5元</span></li>
          <li>100 <span>送5元</span></li>
          <li>100 <span>送5元</span></li>
          <li>100 <span>送5元</span></li>
          <li>100 <span>送5元</span></li>
        </ul>
      </div>
      <div class="blank"></div>
      <div class="pay_psw" style="position: fixed; top: 8rem; left: 1.2rem; z-index: 999; display: none">
        <div class="title">
          <span> 请输入支付密码</span> <span class="close"></span>
        </div>
        <div class="passwordDiv">
          <label for="ipt" class="passwordLabel">
            <ul>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
          </label>
          <input type="password" id="password" name="password" maxlength="6">
        </div>
      
        <div class="tips">
          <p>提示：<a style="color: #f92560"></a></p>
          <a href="/index.php/Mobile/User/forget_pwd.html"> <span>忘记密码？</span></a>
        </div>
      </div>
    </form>
  
    <group title="slot:each-item">
      <radio :options="radio001">
        <template slot-scope="props" slot="each-item"><!-- use scope="props" when vue < 2.5.0 -->
          <p>
            <img src="http://dn-placeholder.qbox.me/110x110/FF2D55/000" class="vux-radio-icon"> {{ props.label }}
          </p>
        </template>
      </radio>
    </group>
    <x-button class="submit" @click="sub(this)" type="primary">确认充值</x-button>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import {Group, Radio,XInput,XButton,XNumber} from "vux"
  
  export default {
    components: {
      Group, Radio,
      navbar,  XNumber, XInput,XButton
    },
    name: 'recharge',
    data() {
      return {
        radio001: [ 'China', 'Japan' ],
        radio003: [{
          icon: 'http://dn-placeholder.qbox.me/110x110/FF2D55/000',
          value: '微信支付',
          key: '001',
        }, {
          icon: 'http://dn-placeholder.qbox.me/110x110/FF2D55/000',
          value: '微信支付',
          key: '002',
        }]
      }
    },
    methods: {
      change (value, label) {
        console.log('change:', value, label)
      }
    }
  }
</script>

<style scoped>
  html,body{
    font-size: 14px;
  }
  .submit{
    height: 2rem;
    margin-top: 2rem;
    width:90%;
    line-height:2rem;
    font-size: 0.8rem;
    color: #fff;
  }
 .bawhite p{
    padding:0.4rem 3.5rem;
  }
  .bawhite li.turnRed {
    background: #f92560;
    color: #ffffff;
  }
  .bawhite li {
    overflow: hidden;
    position: relative;
    cursor: pointer;
    width: 40%;
    height: 3rem;
    line-height: 3rem;
    float: left;
    text-align: center;
    border: 1px solid #e8e8e8;
    margin: 0 0.9rem 0.8rem 1.0rem;
    font-size: 0.6rem;
  }
  .bawhite li span{
    -webkit-transform: rotate(51deg);
    transform: rotate(40deg);
    display: inline-block;
    width: 4rem;
    height: 1.5rem;
    line-height:2.0rem;
    position: absolute;
    right: -1.7rem;
    background: gray;
    color: #ffffff;
    font-size: 0.1rem;
   padding-right: 0.5rem;
  }
  .mobil_topup .bawhite {
    background: white;
  }
  .ma-to-20 {
    margin-top: .42667rem;
  }
  
  .bawhite ul{
    width:80%;
    margin:0 auto;
  }

  .header:nth-child(1){
    border-bottom: 1px solid #dddddd;
  }
  .header{
    font-size:0.6rem;
    height: 3rem;
    line-height: 3rem;
    padding:0 3rem;
  }
  .header input{
    position: relative;
    top:0.1rem;
    padding:0 0.5rem;
    border:none;
  }
  .label{
    display: inline-block;
    margin:0 0.5rem;
  }
</style>
