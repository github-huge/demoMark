<template>
  <div class="">
    <navbar>我要投资</navbar>
    <div class="nosubmit">
      <group>
        <x-input title="姓名" placeholder="请输入姓名" ></x-input>
        <x-input title="城市意向" placeholder="请输入城市意向"></x-input>
        <x-input title="投资预算" placeholder="请输入投资预算" ></x-input>
        <x-input  placeholder="请输入手机号"  title="手机号"></x-input>
        <x-input  placeholder="请输入验证码" title="验证码">
          <x-button slot="right" type="primary" mini>发送验证码</x-button>
        </x-input>
      </group>
      <x-button class="submit" @click="sub(this)" type="default">提交</x-button>
    </div>
    
    <success class="submited"> 提交成功</success>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import success from "./success"
  import { XInput,XButton ,Group } from 'vux'

  export default {
    name: 'league',
    components: {
      XInput,XButton,
      navbar,success,Group
    },
    data () {
      return {
        msg: '的规范和你'
      }
    },
    methods:{
      sub (obj){
        console.log(obj)
        $('.submited').show();
        $('.nosubmit').hide()
      }
    }
  }
</script>

<style scoped>
.submit{
  height: 2rem;
  margin-top: 2rem;
  width:90%;
  background: #cccccc;
  line-height:2rem;
  font-size: 0.8rem;
  color: #fff;
}
  .submited{
    display: none;
  }
</style>
