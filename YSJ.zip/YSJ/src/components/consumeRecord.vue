<template>
  <div class="mywallet">
    <navbar>消费记录</navbar>
  
    <div class="content">
      <div class="floor list7">
        <div class="myorder p">
          <div class="content30">
            <a href="javascript:void(0)">
              <div class="order">
                <div class="fl left">
                  <span>下单消费</span>
                  <span class="time">2018-04-09 17:11:55</span>
                </div>
                <div class="fr right">
                  <span class="rest">95,140.00</span>
                  <span class="right_num">-298.00</span>
                </div>
              </div>
            </a>
          </div>
        </div>
        <div class="myorder p">
          <div class="content30">
            <a href="javascript:void(0)">
              <div class="order">
                <div class="fl left">
                  <span>下单消费</span>
                  <span class="time">2018-04-03 17:26:43</span>
                </div>
                <div class="fr right">
                  <span class="rest">96,928.00</span>
                  <span class="right_num">-298.00</span>
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
    
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import {Swiper, SwiperItem} from "vux"
  
  export default {
    components: {
      navbar,
    },
    name: 'rechargeRecord',
    data() {
      return {
        msg: '的规范和你'
      }
    }
  }
</script>

<style scoped>
  .my .content {
    margin: 0;
  }
  .content30 {
    border-bottom: 1px solid #e8e8e8;
    padding: 0 0.6rem;
  }
  .myorder a {
    overflow: hidden;
    display: block;
    color: #232326;
    text-decoration: none;
    vertical-align: middle;
  }
  .myorder .order .left {
    height: 2.2rem;
    line-height: 1.6rem;
  }
  .myorder .order .right {
    line-height: 2.56rem;
  }
  .myorder .order .fr {
    margin-top: .08533rem;
  }

  .myorder .order .left span {
    line-height: 0;
  }
  .myorder .order .fl span {
    font-size: .7rem;
    vertical-align: middle;
    font-weight: normal;
    margin-left: .21333rem;
  }
  
  .myorder .order .left .time {
    line-height: 0.7rem;
    display: block;
    font-size: 0.5rem;
    color: #999999;
  }
  .myorder .order .left span {
    line-height: 0;
  }
  .myorder .order .fl span {
    font-size: 0.7rem;
    vertical-align: middle;
    font-weight: normal;
    margin-left: .21333rem;
  }

  .myorder .order .right {
    line-height: 2.56rem;
  }
  .myorder .order .fr {
    margin-top: .08533rem;
  }


  .myorder .order .fr span.right_num {
    position: relative;
    top: 0.2rem;
    font-size: 0.7rem;
    line-height: 1.23rem;
    float: none;
    display: block;
    margin-top: -.04267rem;
  }
  .myorder .order .fr span.rest {
    line-height: 1.25rem;
    color: #999999;
    font-size: 0.5rem;
  }
  .myorder .order .fr span {
    float: left;
    margin-top: -.04267rem;
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
</style>
