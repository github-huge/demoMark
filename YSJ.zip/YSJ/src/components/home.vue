<template>
  <div class="hello">
   <div> <navbar>首页</navbar></div>
    <ul>
      <li>
        <router-link to="/caseIntro">方案介绍</router-link>
      </li>
      <li>
        <router-link to="/scan">扫码取水</router-link>
      </li>
      <li>
        <router-link to="/devicelist">设备列表</router-link>
      </li>
      <li>
        <router-link to="/caseIntro">设备查看</router-link>
      </li>
      <li>
        <router-link to="/Loading_machine">我要装机</router-link>
      </li>
      <li>
        <router-link to="/mywallet">我的钱包</router-link>
      </li>
      <li>
        <router-link to="/onlineKf">在线客服</router-link>
      </li>
      <li>
        <router-link to="/league">我要加盟 </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
  import '../assets/css/index.css'
  import axios from "axios";
  import navbar from "./navbar"
  import { Swiper, SwiperItem } from "vux"
  export default {
    name: 'Home',
    components: {
      Swiper,
      SwiperItem,
      navbar,
    },
    data () {
      return {
        msg: '的规范和你'
      }
    },
    methods:{
    
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped="">
  ul {
    padding:1rem 0.6rem;
    overflow: hidden;
    clear: both;
  }
  
  li {
    text-align: center;
    width: 33%;
    float: left;
  }
  a{
    color: #333333;
    text-decoration: none;
    display: inline-block;
  }
  .router-link-active {
    text-decoration: none;
  }
</style>
