<template>
  <div class="zh">
    <navbar></navbar>
    <group title="slot:each-item">
      <radio :options="radio001">
        <template slot-scope="props" slot="each-item"><!-- use scope="props" when vue < 2.5.0 -->
          <p>
            <img src="http://dn-placeholder.qbox.me/110x110/FF2D55/000" class="vux-radio-icon"> {{ props.label }}
          </p>
        </template>
      </radio>
    </group>
    <x-button class="submit" @click="sub(this)" type="default">确认充值</x-button>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import {Group, Radio,XInput,XButton,XNumber} from "vux"
  
  export default {
    components: {
      Group, Radio,
      navbar,  XNumber, XInput,XButton
    },
    name: 'payconfirm',
    data() {
      return {
        radio001: [ 'China', 'Japan' ],
        radio003: [{
          icon: 'http://dn-placeholder.qbox.me/110x110/FF2D55/000',
          value: '微信支付',
          key: '001',
        }, {
          icon: 'http://dn-placeholder.qbox.me/110x110/FF2D55/000',
          value: '微信支付',
          key: '002',
        }]
      }
    },
    methods: {
      change (value, label) {
        console.log('change:', value, label)
      }
    }
  }
</script>

<style scoped>

</style>
