<template>
  <div class="mywallet">
    <navbar>我的钱包</navbar>
    <div class="wallet">
      <p class="counts">10000.00</p>
      <p>账户余额</p>
    </div>
    <div class="blank"></div>
    
    <ul>
      <router-link to="/rechargeCompony">
        <li>
          <img class="fl" src="../assets/images/index/icon_psw_show_s@2x.png" alt="">
          <span>充值</span>
          <img class="fr" src="../assets/images/index/icon_right.png" alt="">
        </li>
      </router-link>
      <div class="blank"></div>
      <router-link to="/consumeRecord">
        <li>
          <img class="fl" src="../assets/images/index/icon_psw_show_s@2x.png" alt="">
          <span>消费记录</span>
          <img class="fr" src="../assets/images/index/icon_right.png" alt="">
        </li>
      </router-link>
    </ul>
    <div class="blank"></div>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import {Swiper, SwiperItem} from "vux"
  
  export default {
    components: {
      Swiper,
      SwiperItem,
      navbar,
    },
    name: 'mywallet',
    data() {
      return {
        msg: '的规范和你'
      }
    }
  }
</script>

<style scoped>
  body{
    background: #F2F4F7;
  }
  li {
    height:2.5rem;
    line-height: 2.5rem;
    padding: 0 0.6rem;
    font-size: 0.6rem;
  }
  
  li img{
    position: relative;
    top:0.3rem;
  }
  .fr {
    width: 0.5rem;
    position: relative;
    top:0.5rem;
  }
  
  .fl {
    margin-right: 0.6rem;
  }
  a{
    text-decoration: none;
    color: #333333;
  }
</style>
