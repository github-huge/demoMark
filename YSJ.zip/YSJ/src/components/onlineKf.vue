<template>
  <div>
    <navbar>在线客服</navbar>
    <div class="talk_con">
      <div class="talk_show" id="words" >
        <div v-for="msg in serverSay"  class="atalk"><span id="asay">{{msg}}</span></div>
        <div v-for="msg in Isay" class="btalk"><span id="bsay">{{msg}}</span></div>
      </div>
    </div>
    
    <div class="talk_input">
      <input type="text" class="talk_word" id="talkwords">
      <input type="button" value="发送" class="talk_sub" @click="TalkSub" id="talksub">
    </div>
    <div v-if="isempty" class="alertmsg"><span>消息不能為空</span></div>
    
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import alert from "./alert"
  import {Group, Radio, XInput, XButton, XNumber,Alert} from "vux"
  export default {
    name: 'onlineKf',
    components: {
      Group, Radio,Alert,
      navbar, XNumber, XInput, XButton
    },
    data() {
      return {
        Isay:[],serverSay:[],show:'hdj',isempty:false,
      }
    },
    mounted() {
    
    },
    methods: {
      TalkSub(e) {
        var TalkWords = document.getElementById("talkwords");
        console.log(this);
        if ( TalkWords.value == "") {
          this.isempty = true;
          setTimeout(function () {
            console.log(this.isempty);
            this.isempty = false;
          }.bind(this),2000);
          return;
        }
        this.serverSay.push('服务器繁忙');
        this.Isay.push(TalkWords.value);
        TalkWords.value = ''
      }
    }
  }
</script>

<style scoped>
  .alertmsg {
    -webkit-border-radius: 0.2rem;
    padding:0.2rem 0;
    text-align: center;
    height: 2rem;
    width: 10rem;
    position: fixed;
    left: 50%;
    top:50%;
    margin-left: -5rem;
    margin-top:-1rem;
    background: rgba(0,0,0,0.3);
  }
  .alertmsg span{
    color: #ffffff;
    padding:0.2rem 0.5rem;
  }
  #talksub {
    border: none;
    outline: none;
    background: #2ac845;
    color: #ffffff;
  }
  
  .talk_con {
    width: 100%;
    height: auto;
    background: #f9f9f9;
  }
  
  .talk_show {
    background: #fff;
    margin: 0.4rem auto 0;
    overflow: auto;
  }
  
  .talk_input {
    padding: 0.6rem;
    width: 100%;
    position: fixed;
    bottom: 0;
    background: #F2F4F7;
    margin: 0.4rem auto 0;
  }
  
  .talk_word {
    box-shadow:none;
    width: 80%;
    height: 2rem;
    padding: 0;
    float: left;
    outline: none;
    text-indent: 0.6rem;
    -webkit-border-radius: 1rem;
    border-radius: 1rem;
  }
  
  .talk_sub {
    width: 3.5rem;
    height: 2rem;
    float: left;
    margin-left: 0.5rem;
  }
  
  .atalk {
    margin: 0.5rem;
    max-width: 90%;
  }
  
  .atalk span {
    display: inline-block;
    background: #0181cc;
    border-radius: 0.3rem;
    color: #fff;
    padding: 0.2rem 0.5rem;
  }
  
  .btalk {
    margin: 0.4rem;
    text-align: right;
    max-width: 90%;
  }
  
  .btalk span {
    display: inline-block;
    background: #ef8201;
    border-radius: 0.3rem;
    color: #fff;
    padding: 0.25rem 0.5rem;
  }
</style>
