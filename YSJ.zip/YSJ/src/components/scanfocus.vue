<template>
  <div class="">
    <navbar>扫码添加设备</navbar>
    <figure>
      <img src="../assets/images/index/icon_clock1@2x.png" alt="">
      <figcaption>
        <slot>扫一扫添加你要关注的设备</slot>
      </figcaption>
    </figure>
    
    <flexbox justify="center">
      <flexbox-item>
        <x-button class="tips" type="plane">该设备未注册</x-button>
      </flexbox-item>
    </flexbox>
  </div>
</template>

<script>
  import navbar from "./navbar";
  import {
    XButton, Box,
    GroupTitle,
    Group,
    Flexbox,
    FlexboxItem,
    Divider
  } from 'vux'
  
  export default {
    name: 'scanfocus',
    data() {
      return {
        msg: '的规范和你'
      }
    },
    components: {
      navbar, XButton, Box, GroupTitle, Group, Flexbox, FlexboxItem, Divider
    },
  }
</script>

<style scoped>
  figure {
    text-align: center;
    padding: 2rem 0;
  }
  
  figure img {
    width: 60%;
    height: 8rem;
  }
  
  figcaption {
    font-size: 0.7rem;
    color: #666;
    margin-top: 0.6rem;
  }
  .tips{
    margin-top:4rem;
    width:10rem;
    background: #000;
    opacity:0.5;
  }
</style>
