<template>
  <div class="">
    <header class="ffc">
      <div class="ds-in-bl">
        <a href="javascript:history.go(-1)"><img src="../assets/images/index/icon_back.png" alt="返回"></a>
      </div>
      <div class="ds-in-bl title">
        <div><span><slot>我的蜂巢</slot></span></div>
      </div>
    </header>
  </div>
</template>

<script>
  export default {
    name: 'barnav',
    data () {
      return {
        msg: '的规范和你'
      }
    }
  }
</script>

<style scoped>
  header {
    background: #F4F4F4;
    padding: 0 0.6rem;
    line-height: 3rem;
  }
  
  .ds-in-bl img {
    width: 0.5rem;
  }
  
  header .title {
    margin-left: 9rem;
  }

</style>
