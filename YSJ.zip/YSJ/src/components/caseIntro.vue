<template>
  <div class="scan">
    <navbar>方案介绍</navbar>
    <div class="caseIntro pd_lr_30">
      <div>
        <img src="../assets/images/index/icon_dagou@2x.png" alt="">
      </div>
      <p>是速度快感受到几个号我更先进吃v浩丰科技 尽快回复说的贵金属的</p>
      <p>是脑袋上考虑很多事那么长VB是滴哦好吧第四批 没得事你计划部分动不动</p>
    </div>
  </div>
</template>
<script>
  import axios from "axios";
  import navbar from "./navbar"
  import { Swiper, SwiperItem } from "vux"
  export default {
    components: {
      Swiper,
      SwiperItem,
      navbar,
    },
    name: 'caseIntro',
    data () {
      return {
        msg: '的规范和你'
      }
    }
  }
</script>

<style scoped>

</style>
