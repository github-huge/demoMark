<template>
  <div >
    <navbar>充值记录</navbar>
    <div class="group">
      <group style="margin: 0;">
        <cell title="当啊当旺网络科技" value="已支付"></cell>
        <cell-form-preview :list="list"></cell-form-preview>
        <cell title="剩余2秒" value=""><span>立即充值</span></cell>
      </group>
  
      <group>
        <cell title="当啊当旺网络科技" value="已支付"></cell>
        <cell-form-preview :list="list"></cell-form-preview>
        <cell title="剩余2秒" value=""> <span>立即充值</span></cell>
      </group>
  
  
      <group>
        <cell title="当啊当旺网络科技" value="已支付"></cell>
        <cell-form-preview :list="list"></cell-form-preview>
      </group>
    </div>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import { CellFormPreview, Group, Cell } from 'vux'
  
  export default {
    components: {
      navbar,CellFormPreview, Group, Cell
    },
    name: 'rechargeRecord',
    data() {
      return {
        list: [{
          label: 'Apple',
          value: '3.29'
        }, {
          label: 'Banana',
          value: '1.04'
        }, {
          label: 'Fish',
          value: '8.00'
        }]
      }
    }
  }
</script>

<style scoped>
  .group{
    background: #F2F2F2;
  }

</style>
