<template>
  <div class="">
    <navbar>扫码取水</navbar>
    <div class="qrcode">
      <img src="../assets/images/index/icon_dagou@2x.png" alt="">
    </div>
    
    
    <div class="bill">
      <div class="tit">
        <p>确认付款</p>
        <p>￥10</p>
        <div class="blank"></div>
      </div>
      <group title="选择支付方式">
        <radio :options="radio001">
          <template slot-scope="props" slot="each-item"><!-- use scope="props" when vue < 2.5.0 -->
            <p>
              <img src="http://dn-placeholder.qbox.me/110x110/FF2D55/000" class="vux-radio-icon"> {{ props.label }}
            </p>
          </template>
        </radio>
      </group>
     
        <x-button class="submit" @click="sub(this)" type="default">确认支付</x-button>
    </div>
    <div v-if="flag" class="shade"> </div>
    <alert v-if="flag"></alert>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import alert from "./alert"
  import {Group, Radio, XInput, XButton , XNumber,} from "vux"
  
  
  export default {
    name: 'scan',
    components: {
      Group, Radio,alert,
      navbar, XNumber, XInput, XButton
  
    },
    data() {
      return {
        flag:false,
        radio001: ['China', 'Japan'],
        radio003: [{
          icon: 'http://dn-placeholder.qbox.me/110x110/FF2D55/000',
          value: '微信支付',
          key: '001',
        }, {
          icon: 'http://dn-placeholder.qbox.me/110x110/FF2D55/000',
          value: '微信支付',
          key: '002',
        }]
      }
    },
    methods: {
      sub() {
       this.flag = !this.flag
        console.log( this.flag)
      }
    }
  }
</script>

<style scoped>
  .qrcode img {
    display: block;
    margin: 2rem auto;
    width: 70%;
    height: 10rem;
  }
  
  .bill .tit p {
    text-align: center;
    padding: 0.3rem;
  }
  
  .submit {
    height: 2rem;
    margin-top: 2rem;
    width: 90%;
    background: #cccccc;
    line-height: 2rem;
    font-size: 0.8rem;
    color: #fff;
  }
  .shade{
    width:100%;
    height:100%;
    position: fixed;
    top:0;
    z-index: 99;
    background: rgb(0,0,0);
    opacity: 0.6;
  }
</style>
