<template>
  <div class="water contaner">
    <navbar>水质详情</navbar>
    <table>
      <thead><th colspan="3">表头</th></thead>
      <tr>
        <td>都是广东省</td>
        <td>都是广东省</td>
        <td>都是广东省</td>
      </tr>
      <tr>
        <td>都是广东省</td>
        <td>都是广东省</td>
        <td>都是广东省</td>
      </tr>
      <tr>
        <td>都是广东省</td>
        <td>都是广东省</td>
        <td>都是广东省</td>
      </tr>
      <tr>
        <td>都是广东省</td>
        <td>都是广东省</td>
        <td>都是广东省</td>
      </tr>
      <tr>
        <td>都是广东省</td>
        <td>都是广东省</td>
        <td>都是广东省</td>
      </tr>
      <tr>
        <td>都是广东省</td>
        <td>都是广东省</td>
        <td>都是广东省</td>
      </tr>
      <tr>
        <td>都是广东省</td>
        <td>都是广东省</td>
        <td>都是广东省</td>
      </tr>
    </table>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import {Swiper, SwiperItem} from "vux"
  
  export default {
    components: {
      Swiper,
      SwiperItem,
      navbar,
    },
    name: 'waterQulity',
    data() {
      return {
        msg: 'waterQulity'
      }
    }
  }
</script>

<style scoped>

</style>
