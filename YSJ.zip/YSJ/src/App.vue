<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
//  import '../../src/assets/js/mui/js/mui.js';
export default {
  name: 'app'
}
</script>

<style lang="less">
@import '~vux/src/styles/reset.less';

.vux-no-group-title{
  margin-top: 0!important;
  font-size: 0.8rem;
}
.vux-label{
    display: inline!important;
    width:6rem;
  }
.vux-cell-bd p{
  width:6rem;
}
.facilityNum .vux-cell-primary div{
  height: 2rem;
}

.facilityNum .vux-cell-primary div a, .facilityNum .vux-cell-primary div input{
  height: 2rem;
  line-height:2rem;
}
.facilityNum .vux-cell-primary  div .vux-number-selector-sub{
  line-height:1.5rem;
}

.facilityNum .vux-cell-primary  div  .vux-number-selector-plus{
    padding:0 0.33rem ;
  }
</style>
