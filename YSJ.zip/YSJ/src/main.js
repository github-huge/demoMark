// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import FastClick from 'fastclick'
import VueRouter from 'vue-router'
import App from './App'

import Home from './components/home'
import navbar from './components/navbar'

import caseIntro from './components/caseIntro'

import devicelist from './components/devicelist'
import waterQulity  from './components/waterQulity'
import scan  from './components/scan'
import mywallet  from './components/mywallet'
import filterStatus from './components/filterStatus'
import league from './components/league'
import Loading_machine from './components/Loading_machine'
import success from './components/success'
import alert from './components/alert'

import helpme from './components/helpme'
import recharge from './components/recharge'
import rechargeCompony from './components/rechargeCompony'
import consumeRecord from './components/consumeRecord'
import rechargeRecord from './components/rechargeRecord'
import scanfocus from './components/scanfocus'
import onlineKf from './components/onlineKf'



Vue.use(VueRouter)
const routes = [
  {
    path: '/',
    component: Home
  },
  {
    path: '/navbar',
    name: 'navbar',
    component: navbar
  },
  {
    path: '/caseIntro',
    name: 'caseIntro',
    component: caseIntro
  },
  {
    path: '/filterStatus',
    name: 'filterStatus',
    component: filterStatus
  },
  {
    path: '/devicelist',
    name: 'devicelist',
    component: devicelist
  },
  {
    path: '/waterQulity',
    name: 'waterQulity',
    component: waterQulity
  }, {
    path: '/mywallet',
    name: 'mywallet',
    component: mywallet
  }, {
    path: '/scan',
    name: 'scan',
    component: scan
  }, {
    path: '/league',
    name: 'league',
    component: league
  }, {
    path: '/Loading_machine',
    name: 'Loading_machine',
    component: Loading_machine
  }, {
    path: '/success',
    component: success
  },
  {
    path: '/helpme',
    component: helpme
  },
  {
    path: '/recharge',
    component: recharge
  },
  {
    path: '/consumeRecord',
    component: consumeRecord
  },
  {
    path: '/alert',
    component: alert
  },
  {
    path: '/rechargeRecord',
    component: rechargeRecord
  },
  {
    path: '/scanfocus',
    component: scanfocus
  }, {
    path: '/rechargeCompony',
    component: rechargeCompony
  },
  {
    path: '/onlineKf',
    component: onlineKf
  },
]

const router = new VueRouter({
  routes
})

FastClick.attach(document.body)

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  router,
  render: h => h(App)
}).$mount('#app-box')
