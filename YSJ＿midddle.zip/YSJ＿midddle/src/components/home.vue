<template>
  <div class="hello">
   <div> <navbar>首页</navbar></div>
    <ul>
      <li>
        <router-link to="/caseIntro">学习资料详情</router-link>
      </li>
      <li>
        <router-link to="/login">管理平台</router-link>
      </li>
      <li>
        <router-link to="/user">我的中心</router-link>
      </li>
      <li>
        <!--<router-link to="/caseIntro">设备查看</router-link>-->
      </li>
      <li>
        <router-link to="/plan">计划备案</router-link>
      </li>
      <li>
        <router-link to="/mywallet">关于公司</router-link>
      </li>
      <li>
        <router-link to="/personInfro">个人信息</router-link>
      </li>
      <li>
        <router-link to="/Overview">信息总览 </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
  import '../assets/css/index.css'
  import axios from "axios";
  import navbar from "./navbar"
  import { Swiper, SwiperItem } from "vux"
  export default {
    name: 'Home',
    components: {
      Swiper,
      SwiperItem,
      navbar,
    },
    data () {
      return {
        msg: '的规范和你'
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped="">
  ul {
    position: fixed;
    width: 100%;
    bottom:0;
    padding:1rem 0.6rem;
     overflow: hidden;
    clear: both;
  }
  
  li {
    text-align: center;
    width: 33%;
    float: left;
  }
  a{
    color: #333333;
    text-decoration: none;
    display: inline-block;
  }
  .router-link-active {
    text-decoration: none;
  }
</style>
