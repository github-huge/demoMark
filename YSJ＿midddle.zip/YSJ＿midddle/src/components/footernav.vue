<template>
  <div class="">
     <footer>
       <ul>
         <router-link to="./"> <li>设备</li></router-link>
         <router-link to="./upload"> <li>合同</li></router-link>
         <router-link to="./systerMsg"> <li>信息</li></router-link>
       </ul>
     </footer>
  </div>
</template>

<script>
  export default {
    name: 'footernav',
    data() {
      return {
      
      }
    }
  }
</script>

<style scoped>
  footer {
    width: 100%;
    position: fixed;
    bottom:0;
    background: #F4F4F4;
    padding: 0 0.6rem;
    line-height: 3rem;
  }
  ul{
    overflow: hidden;
    clear: both;
  }
  li{
    text-align: center;
    float: left;
    width:33%;
    color: #666666;
  }
  
</style>
