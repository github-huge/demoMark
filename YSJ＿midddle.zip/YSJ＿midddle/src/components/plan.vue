<template>
  <div class="plan">
    <navbar>计划/备案<span slot="bar_right">项目备案</span></navbar>
     <p class="title">销售任务</p>
     <div class="cellbox">
        <p class="tit"><img src="../assets/images/nodata/icon_wudingdan.png" alt=""><span>计划</span></p>
         <p>设备数量：10</p>
       <p>设备金额：200</p>
     </div>
    <div class="blank"></div>
    <div class="cellbox">
      <p class="tit"><img src="../assets/images/nodata/icon_wudingdan.png" alt="">实际</p>
      <p>设备数量：10</p>
      <p>设备金额：200</p>
    </div>
    <div class="blank"></div>
    <div class="cellbox">
      <p class="tit"><img src="../assets/images/nodata/icon_wudingdan.png" alt="">统计</p>
       <div class="ffc tit3">
         <img src="../assets/images/nodata/icon_wudingdan.png" alt="">
         <ul>
           <li>设备数量占比：</li>
           <li>设备金额占比：</li>
         </ul>
       </div>
    </div>
  </div>
</template>


<script>
  import success from "./success"
  import navbar from "./navbar"
  import { XInput,XButton ,Group,XTextarea,Cell,Datetime  } from 'vux'
  
  export default {
    components: {
      XInput,XButton,XTextarea, navbar,success,Group,Cell,Datetime
    },
    name: 'plan',
    data() {
      return {
      
      }
    },
    methods: {
    
    },
  }
</script>


<style scoped="">
  .title{
    margin-left:0;
    line-height:2.5rem;
  }
  .plan{
    height: 100vh;
    color: #666666;
    padding:0 0.6rem;
    background: #F4F4F4
  }
  .cellbox{
    background: #ffffff;
    padding:0.6rem 0;
    border-radius: 0.4rem;
    -webkit-border-radius: 0.4rem;
  }
  .tit{
    margin-left:0;
  }
  .tit img{
    margin:0 0.3rem;
    width: 1.5rem;
    position: relative;
    top:0.3rem;
  }
  .tit3 img{
    width:5rem;
    height: 5rem;
    margin:0 2.5rem;
    display: block;
  }
  p{
    margin-left:2rem;
    line-height:1.5rem;
  }
  
  ul{
    padding-top:1rem;
  }
  li{
    list-style:circle ;
  }
</style>
