<template>
  <div class="mywallet">
    <navbar>上传合同 <span slot="bar_right">合同管理</span></navbar>
    <div class="nosubmit">
      <group>
        <x-input title="单位名称" placeholder="请输入单位名称"></x-input>
        <x-input title="联系人" placeholder="请输入联系人"></x-input>
        <x-input title="联系电话" placeholder="请输入联系电话"></x-input>
        <x-input title="联系地址" placeholder="请输入签约时间"></x-input>
        <x-input title="签约时间" placeholder="请输入签约时间"></x-input>
        <x-input title="合同号" placeholder="请输入合同号"></x-input>
        <datetime v-model="value1" @on-change="change" title="装机时间" @on-cancel="log('cancel')" @on-confirm="onConfirm" @on-hide="log('hide', $event)"></datetime>
        <!--<x-textarea title="合同附件" :max="200" placeholder="请输入合同附件" :show-counter="true" :height="100" :rows="8" :cols="30"> </x-textarea>-->
          <!--照片添加 -->
          <div class="container">
            <div class="z_photo">
              <div class="z_file" v-if="imgArrs.length < 5" >
                <input  @change="imgChange(this);" type="file" name="file" id="file" accept="image/*" multiple/>
              </div>
              <div class="z_addImg"   v-for="(item,index) in imgArr" @click="isDel(index)">
                <img :src="item">
              </div>
            </div>
          </div>
          <!--遮罩层-->
          <div class="z_mask" v-if="alert">
            <!--弹出框-->
            <div class="z_alert">
              <p>确定要删除这张图片吗？</p>
              <p>
                <span class="z_cancel" @click="cancel">取消</span>
                <span class="z_sure" @click="sure">确定</span>
              </p>
            </div>
          </div>
       
        <cell title="收款方" value="苏州智享环保科技有限公司"  is-link></cell>
      </group>
      <x-button class="submit" @click="sub(this)" type="primary">提交</x-button>
    </div>
    <success class="submited"> 项目备案成功</success>
  </div>
</template>
<i18n>
  Choose:
  zh-CN: 选择
  daterange-format:
  en: 'YYYY/MM/DD'
  zh-CN: 'YYYY年MM月DD日'
</i18n>

<script>
  import success from "./success"
  import navbar from "./navbar"
  import { XInput,XButton ,Group,XTextarea,Cell,Datetime  } from 'vux'
  
  export default {
    components: {
      XInput,XButton,XTextarea, navbar,success,Group,Cell,Datetime
    },
    name: 'upload',
    data() {
      return {
        imgArrs:[],imgArr:[],alert:false,curimg:null,curIndex:null,
        value1: '2015-11-12',
        value: ['2017-01-15', '03', '05']
      }
    },
    methods: {
      log (str1, str2 = '') {
        console.log(str1, str2)
      },
      change (value) {
        console.log('change', value)
      },
      onConfirm (val) {
        console.log('on-confirm arg', val)
        console.log('current value', this.value1)
      },
      showPlugin () {
        this.$vux.datetime.show({
          cancelText: '取消',
          confirmText: '确定',
          format: 'YYYY-MM-DD HH',
          value: '2017-05-20 18',
          onConfirm (val) {
            console.log('plugin confirm', val)
          },
          onShow () {
            console.log('plugin show')
          },
          onHide () {
            console.log('plugin hide')
          }
        })
      },
      imgChange() {
        //获取点击的文本框
        let file = document.getElementById("file");
        //获取的图片文件
        let fileList = file.files;
//     console.log(fileList)
        //遍历获取到得图片文件
        Array.prototype.push.apply(this.imgArrs, fileList);
    
        if (this.imgArrs.length > 5) {
          //移除伪組裡面的fileList 避免上传
          this.imgArrs.splice(0, file.files.length);
          alert('最多只能传5张');
          console.log(this.imgArrs);
          console.log(this.imgArrs.length);
          return;
        } else {
          for (let i = 0; i < fileList.length; i++) {
            if (fileList.length > 5) {
              this.imgArrs = [];
              console.log(this.imgArrs)
              alert('最多只能传5张');
              return;
            }
            let imgUrl = window.URL.createObjectURL(file.files[i]);
            this.imgArr.push(imgUrl);
          }
          console.log(this.imgArrs);
          console.log(this.imgArrs.length)
        }
      },
      isDel(i){
        this.curIndex = i;
        this.alert = true;
        console.log(this.imgArrs);
        console.log(this.imgArr);
      },
      sure(){
        console.log(this.curIndex);
        this.imgArrs.splice(this.curIndex, 1);
        this.imgArr.splice(this.curIndex, 1);
        console.log(this.imgArrs);
        console.log(this.imgArr);
        this.alert = false
      },
      cancel(){
        this.alert = false
      }
    },
  }
</script>

<style scoped>
  .submit{
    height: 2rem;
    margin-top: 2rem;
    width:90%;
    line-height:2rem;
    color: #fff;
  }

  .submited{
    display: none;
  }

  .z_photo {
    padding: 0.3rem;
    overflow: auto;
    clear: both;
  }

  .z_photo img {
    width: 4.2rem;
    height: 4.2rem;
  }

  .z_addImg{
    float: left;
    margin-right: 0.4rem;
  }

  .z_file {
    position: relative;
    width: 4.2rem;
    height: 4.2rem;
    background: url('../assets/images/z_add.png') no-repeat;
    background-size:cover;
    margin-left: 0.4rem;
    display: inline-block;
  }

  .z_file input {
    opacity:0;
    position: absolute;
    display: inline-block;
    width: 3.2rem;
    height:3.4rem;
    top:0;
    border: 0;
    vertical-align: middle;
  }

  /*遮罩层*/
  .z_mask {
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, .5);
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999;
  }

  .z_alert {
    width: 14rem;
    height: 4rem;
    border-radius: .2rem;
    background: #fff;
    font-size: .24rem;
    text-align: center;
    position: absolute;
    left: 50%;
    top: 50%;
    margin-left: -7rem;
    margin-top: -4rem;
  }

  .z_alert p:nth-child(1) {
    line-height: 2rem;
  }

  .z_alert p:nth-child(2) span {
    display: inline-block;
    width: 49%;
    height: 2rem;
    line-height: 2rem;
    float: left;
    border-top: 1px solid #ddd;
  }

  .z_cancel {
    border-right: 1px solid #ddd;
  }
  .z_addImg:last-of-type{
    margin-right:0;
  }
</style>
