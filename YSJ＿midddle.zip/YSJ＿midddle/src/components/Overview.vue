<template>
  <div class="overview">
    <navbar>信息总览 <span slot="bar_right">添加设备</span></navbar>
    <div class="ser pd_lr_30">
      <img src="../assets/images/search.png" alt="">
      <input placeholder="输入单位名称，区域" type="text">
    </div>
    
    <div class="box pd_lr_30">
       <ul>
         <li>
           <p>设备总数</p>
           <p>200</p>
         </li>
         <li>
           <p>覆盖人数</p>
           <p>200</p>
         </li>
         <li>
           <p>累计总数</p>
           <p>200</p>
         </li>
         <li>
           <p>累计用水</p>
           <p>200</p>
         </li>
       </ul>
    </div>
    <div class="cellBox">
      <p class="title">高科技梵蒂冈</p>
      <p><span>：设备安装天数：</span> <span>恒邦股份那边帮个忙你换个</span></p>
      <p><span>设备状态：</span> <span>恒邦股份那边帮个忙你换个</span></p>
      <p><span>当前收益：</span> <span>恒邦股份那边帮个忙你换个</span></p>
      <p><span>剩余天数/升数：</span> <span>恒邦股份那边帮个忙你换个</span></p>
    </div>
    <div class="blank"></div>
    <footernav class="footer"></footernav>
    <div v-if="flag" class="shade"></div>
    <alert v-if="flag"></alert>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import footernav from "./footernav"
  
  import alert from "./alert"
  import {Group, Radio, XInput, XButton, XNumber,} from "vux"
  
  
  export default {
    name: 'Overview',
    components: {
      Group, Radio, alert, footernav,
      navbar, XNumber, XInput, XButton
      
    },
    data() {
      return {
      
      }
    },
    methods: {
    
    }
  }
</script>

<style scoped>
  .cellBox{
    background: #ffffff;
  }
  .cellBox .title{
    border-bottom: 1px solid #dddddd;
    line-height:2.5rem;
    color: #666666;
  }
  .cellBox p{
    line-height:2.0rem;
    padding:0 0.6rem;
    color: #666666;
  }
  
  .overview {
    height: 100vh;
    background: #F4F4F4;
  }
  
  .ser {
    margin:0 1.0rem;
    border-radius: 1.2rem;
    text-align: center;
    background: #ffffff;
    height: 2.4rem;
    line-height: 2.4rem;
  }
  
  .ser img {
    position: relative;
    top: 0.1rem;
    display: inline-block;
    margin-right: 0.5rem;
    width: 1.0rem;
  }
  
  .ser input {
    border:0;
    width: 60%;
    height: 2.0rem;
    line-height: 2.0rem;
  }
  .box{
    margin-top:1rem;
  }
  ul{
    overflow: hidden;
    clear: both;
  }
  li{
    width:48%;
    float: left;
    margin-bottom:0.5rem
  }
  li p{
    line-height: 2rem;
    color: #ffffff;
    border-radius: 0.2rem;
    background: #cccccc;
    text-align: center;
  }
  li p:nth-child(2){
    background: #ffffff;
    color: #000;
    line-height: 3.5rem;
  }
  li:nth-child(2n + 1){
    margin-right: 0.5rem;
  }
</style>
