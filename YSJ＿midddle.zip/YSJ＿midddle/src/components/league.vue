<template>
  <div class="">
    <navbar>项目备案</navbar>
    <div class="nosubmit">
      <group>
        <x-input title="项目名称" placeholder="请输入姓名" ></x-input>
        <x-input title="安装台数" placeholder="请输入安装台数"></x-input>
        <x-input title="使用人数" placeholder="请输入人数" ></x-input>
        <x-input title="项目预算" placeholder="请输入项目预算" ></x-input>
        <x-input title="项目备注" placeholder="请输入项目备注" ></x-input>
        <x-textarea title="项目备注" :max="200" placeholder="请输入项目备注" :show-counter="true" :height="100" :rows="8" :cols="30"></x-textarea>
      </group>
      <x-button class="submit" @click="sub(this)" type="primary">提交</x-button>
    </div>
    
    <success class="submited"> 项目备案成功</success>
  </div>
  
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import success from "./success"
  import { XInput,XButton ,Group,XTextarea  } from 'vux'

  export default {
    name: 'league',
    components: {
      XInput,XButton,XTextarea,
      navbar,success,Group
    },
    data () {
      return {
        msg: '的规范和你'
      }
    },
    methods:{
      sub (obj){
        console.log(obj)
        $('.submited').show();
        $('.nosubmit').hide()
      }
    }
  }
</script>

<style scoped>
.submit{
  height: 2rem;
  margin-top: 2rem;
  width:90%;
  line-height:2rem;
  font-size: 0.8rem;
  color: #fff;
}
  .submited{
    display: none;
  }
</style>
