<template>
  <div class="scan">
    <navbar>设备列表</navbar>
    <div class="contaner">
      <swiper height="650px"  show-dots="false" loop="true">
        <swiper-item class="swiper-item" v-for="(item, index) in imgArr" :key="index">
          <img :src="item">
        </swiper-item>
        <a @clcik="lastimg()"><img src="../assets/images/index/icon_back.png" alt=""></a>
        <a @clcik="nextimg()"><img src="../assets/images/index/icon_right.png" alt=""></a>
      </swiper>
  
     
    
      <div class="ffc_sb button">
        <router-link to="/filterStatus"><p>剩余80%，滤芯状态</p></router-link>
        <router-link to="/waterQulity"><p>查看水质</p></router-link>
      </div>
    </div>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import {Swiper, SwiperItem} from "vux"
  
  export default {
    components: {
      Swiper,
      SwiperItem,
      navbar,
    }, name: 'devicelist',
    data() {
      return {
        imgArr: ['./static/image/01.jpg', '../../src/assets/images/3.jpg', '../../src/assets/images/2.jpg'],
//        console.log(imgArr)
      }
    }
  }
</script>

<style scoped>
  .swiper-item img {
    height: 100%;
    width: 100%;
  }
  .button p{
    color: #333333;
  }
</style>
