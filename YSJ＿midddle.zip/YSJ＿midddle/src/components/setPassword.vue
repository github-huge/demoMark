<template>
  <div class="">
    <navbar>修改系统密码</navbar>
    <div class="nosubmit">
      <group>
        <x-input type="number"  placeholder="请输入手机号"  title="手机号"></x-input>
        <x-input type="number"  placeholder="请输入验证码" title="验证码">
          <x-button slot="right" type="primary" mini>发送验证码</x-button>
        </x-input>
      </group>
      <x-button class="submit" @click="sub(this)" type="primary">下一步</x-button>
    </div>
    
    <success class="submited"> 提交成功</success>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import success from "./success"
  import { XInput,XButton ,Group } from 'vux'
  
  export default {
    name: 'setPassword',
    components: {
      XInput,XButton,
      navbar,success,Group
    },
    data () {
      return {
        msg: '的规范和你'
      }
    },
    methods:{
      sub (obj){
        console.log(obj)
        $('.submited').show();
        $('.nosubmit').hide()
      }
    }
  }
</script>

<style scoped>
  .submit{
    height: 2rem;
    margin-top: 2rem;
    width:90%;
    line-height:2rem;
    color: #fff;
  }
  .submited{
    display: none;
  }
</style>
