<template>
  <div >
    <navbar>系统消息</navbar>
      <div class="item">
        <p class="tit">系统消息通知</p>
        <p>是还是大杯v 快乐大V好几年搜地 下班是U盾是个我我打算过来来来 我讲哦if个更好是否开始了</p>
      </div>
    <div class="item">
      <p class="tit">系统消息通知</p>
      <p>是还是大杯v 快乐大V好几年搜地 下班是U盾是个我我打算过来来来 我讲哦if个更好是否开始了</p>
    </div>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import { CellFormPreview, Group, Cell } from 'vux'
  
  export default {
    components: {
      navbar,CellFormPreview, Group, Cell
    },
    name: 'systerMsg',
    data() {
      return {
        list: [{
          label: 'Apple',
          value: '3.29'
        }, {
          label: 'Banana',
          value: '1.04'
        }, {
          label: 'Fish',
          value: '8.00'
        }, {
          label: 'Fish',
          value: '8.00'
        }]
      }
    }
  }
</script>

<style scoped>
  .item{
    padding: 0.8rem;
    background: #ffffff;
    border-bottom: 1px solid #dddddd;
  }
  .item .tit{
    padding:0.3rem 0;
    color: #333333;
  }
  .item p{
    line-height: 150%;
    color: #666666;
  }
</style>
