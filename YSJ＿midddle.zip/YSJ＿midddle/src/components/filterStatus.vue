<template>
  <div class="filterStatus">
    <navbar>滤芯状态</navbar>
    <div class="contaner">
      <div class="waterstatus">
        <figure>
          <figcaption>净水水质</figcaption>
          <img src="../assets/images/index/icon_qq@2x.png" alt="">
        </figure>
      </div>
    </div>
    <div class="blank"></div>
    <div class="contaner rate">
      <p>滤芯寿命</p>
      <ul class="ffc ">
        <div>
          <span>cpf</span>
          <li></li>
        </div>
        <div>
          <span>cpf</span>
          <li></li>
        </div>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
      </ul>
      <p>剩余100%</p>
    </div>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import { Swiper, SwiperItem } from "vux"
  export default {
    components: {
      Swiper,
      SwiperItem,
      navbar,
    },    name: 'filterStatus',
    data () {
      return {
        msg: '的规范和你'
      }
    }
  }
</script>

<style scoped>

</style>
