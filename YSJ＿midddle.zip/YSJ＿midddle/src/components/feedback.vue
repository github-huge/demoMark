<template>
  <div class="">
    <navbar>信息反馈</navbar>
    <div class="nosubmit">
      <group>
        <x-textarea :max="200" placeholder="请描述遇到的问题和意见" :show-counter="true" :height="100" :rows="8" :cols="30"></x-textarea>
        <!--照片添加 -->
        <div class="container">
          <div class="z_photo">
            <div class="z_file" v-if="imgArrs.length < 5" >
              <input  @change="imgChange(this);" type="file" name="file" id="file" accept="image/*" multiple/>
            </div>
            <div class="z_addImg"   v-for="(item,index) in imgArr" @click="isDel(index)">
              <img :src="item">
            </div>
          </div>
        </div>
        <!--遮罩层-->
        <div class="z_mask" v-if="alert">
          <!--弹出框-->
          <div class="z_alert">
            <p>确定要删除这张图片吗？</p>
            <p>
              <span class="z_cancel" @click="cancel">取消</span>
              <span class="z_sure" @click="sure">确定</span>
            </p>
          </div>
        </div>
      </group>
      <x-button class="submit" @click="sub(this)" type="primary">提交</x-button>
    </div>
    
    <success class="submited"> 项目备案成功</success>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import success from "./success"
  import {XInput, XButton, Group, XTextarea} from 'vux'
  
  export default {
    name: 'feedback',
    components: {
      XInput, XButton, XTextarea,
      navbar, success, Group
    },
    data() {
      return {
        imgArrs:[],imgArr:[],alert:false,curimg:null,curIndex:null
      }
    },
    methods: {
      sub(obj) {
        console.log(obj)
        $('.submited').show();
        $('.nosubmit').hide()
      },
      
      imgChange() {
        //获取点击的文本框
        let file = document.getElementById("file");
        //获取的图片文件
        let fileList = file.files;
//     console.log(fileList)
        //遍历获取到得图片文件
        Array.prototype.push.apply(this.imgArrs, fileList);
    
        if (this.imgArrs.length > 5) {
          //移除伪組裡面的fileList 避免上传
          this.imgArrs.splice(0, file.files.length);
          alert('最多只能传5张');
          console.log(this.imgArrs);
          console.log(this.imgArrs.length);
          return;
        } else {
          for (let i = 0; i < fileList.length; i++) {
            if (fileList.length > 5) {
              this.imgArrs = [];
              console.log(this.imgArrs)
              alert('最多只能传5张');
              return;
            }
            let imgUrl = window.URL.createObjectURL(file.files[i]);
            this.imgArr.push(imgUrl);
          }
          console.log(this.imgArrs);
          console.log(this.imgArrs.length)
        }
      },
      isDel(i){
        this.curIndex = i;
        this.alert = true;
        console.log(this.imgArrs);
        console.log(this.imgArr);
      },
      sure(){
        console.log(this.curIndex);
        this.imgArrs.splice(this.curIndex, 1);
        this.imgArr.splice(this.curIndex, 1);
        console.log(this.imgArrs);
        console.log(this.imgArr);
        this.alert = false
      },
      cancel(){
        this.alert = false
      }
    }
  }
</script>

<style scoped>
  .submit {
    height: 2rem;
    margin-top: 2rem;
    width: 90%;
    line-height: 2rem;
    font-size: 0.8rem;
    color: #fff;
  }
  
  .submited {
    display: none;
  }
  
  .container {
    width: 100%;
    height: 100%;
    overflow: auto;
    clear: both;
  }
  
  .z_photo {
    padding: 0.3rem;
    overflow: auto;
    clear: both;
  }
  
  .z_photo img {
    width: 4.2rem;
    height: 4.2rem;
  }
  
  .z_addImg{
    float: left;
    margin-right: 0.4rem;
  }
  
  .z_file {
    position: relative;
    width: 4.2rem;
    height: 4.2rem;
    background: url('../assets/images/z_add.png') no-repeat;
    background-size:cover;
    margin-left: 0.4rem;
    display: inline-block;
  }
  
  .z_file input {
    opacity:0;
    position: absolute;
    display: inline-block;
    width: 3.2rem;
    height:3.4rem;
    top:0;
    border: 0;
    vertical-align: middle;
  }
  
  /*遮罩层*/
  .z_mask {
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, .5);
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999;
  }
  
  .z_alert {
    width: 14rem;
    height: 4rem;
    border-radius: .2rem;
    background: #fff;
    font-size: .24rem;
    text-align: center;
    position: absolute;
    left: 50%;
    top: 50%;
    margin-left: -7rem;
    margin-top: -4rem;
  }
  
  .z_alert p:nth-child(1) {
    line-height: 2rem;
  }
  
  .z_alert p:nth-child(2) span {
    display: inline-block;
    width: 49%;
    height: 2rem;
    line-height: 2rem;
    float: left;
    border-top: 1px solid #ddd;
  }
  
  .z_cancel {
    border-right: 1px solid #ddd;
  }
  .z_addImg:last-of-type{
    margin-right:0;
  }
</style>
