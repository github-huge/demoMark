<template>
  <div>
      <div class="alert">
        <p class="border_bottom"> 支付<span @click="isshow" class="fr">x</span></p>
        <p>余额不足 <br> 充值可享优惠</p>
        <router-link  class="submit" to="/recharge">立即充值</router-link>
      </div>
  </div>
</template>

<script>
  import {Group, Radio,XInput,XButton,XNumber} from "vux"
  export default {
    name: 'alert',
    componet:{XButton},
    data () {
      return {
        msg: '的规范和你',
        isalert:false,
        isshade:false
      }
    },
    methods: {
      isshow() {
        this.isalert = ! this.isalert
        this.isshade = ! this.isshade
        console.log(this.isalert)
      }
    }
  }
</script>

<style scoped>
  .alert {
    position: fixed;
    width: 60%;
    height: 10rem;
    background: #ffffff;
    z-index: 999;
    left:50%;
    top: 40%;
    margin-left:-30%;
    margin-top:-3rem;
  }
  
  P{
    text-align: center;
    padding:0.6rem;
    color: #000000;
    font-size: 0.6rem;
  }
  p:nth-child(2){
    text-align: center;
    color: #000;
  }
  P span{
    font-size:1.2rem;
    position: relative;
    top:-0.5rem;
  }
  .border_bottom{
    border-bottom: 1px solid #dddddd;
  }
  .submit{
    font-size:0.6rem;
    margin: 0 auto;
    display:block;
    width: 4rem;
    padding:0.1rem 0.3rem;
    -webkit-border-radius: 0.2rem;
    border-radius: 0.2rem;
    color: #1AAD19;
    border:1px solid #1AAD19;
  }
</style>
