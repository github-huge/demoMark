<template>
  <div class="">
    <navbar>我要装机</navbar>
    <ul>
      <li>
        <span>选择场所</span>
        <span><input name="case" id="row11" type="radio" value="">  <label for="row11">商用</label></span>
        <span><input name="case" id="row12" type="radio" value="">  <label for="row12">民用</label></span>
      </li>
      <li>
        <span>过滤精度</span>
        <span><input name="filter" id="row21" type="radio" value=""> <label for="row21">uf超滤</label></span>
        <span><input name="filter" id="row22" type="radio" value=""><label for="row22">ro反渗透</label></span>
        <span>
          <router-link to="./helpme">
            <label>帮我选择</label>
          </router-link>
        </span>
      </li>
      <li>
        <span>水温要求</span>
        <span><input name="degree" id="row51" type="radio" value=""><label for="row51">常温水</label></span>
        <span><input name="degree" id="row52" type="radio" value=""><label for="row52">100开水</label></span>
        <span><input name="degree" id="row53" type="radio" value=""><label for="row53">10冰水</label></span>
      </li>
      
      <group>
        <x-number class="facilityNum" min="0" name="('Quantity')" title="设备数量"></x-number>
      </group>
      
      <li>
        <span>计费方式</span>
        <span><input name="costway" id="row41" type="radio" value=""><label for="row41">计时</label></span>
        <span><input name="costway" id="row42" type="radio" value=""><label for="row42">计流量</label></span>
        <span><input name="costway" id="row43" type="radio" value=""><label for="row43">买断</label></span>
      </li>
      <li>
        <span>供应人数</span>
        <span> <input name="person" id="row31" type="radio" value=""><label for="row31">1-25人</label></span>
        <span><input name="person" id="row32" type="radio" value=""> <label for="row32">25-60人</label> </span>
        <span><input name="person" id="row33" type="radio" value=""> <label for="row33">61-100人</label> </span>
      </li>
      <group>
        <selector ref="defaultValueRef" title="省份" :options="list" ></selector>
      </group>
      <group>
        <selector title="title" v-model="value"></selector>
      </group>
      <group>
        <cell title="付费周期" value="value"></cell>
        <cell title="平均周期" value="value"></cell>
      </group>
  
      <group>
       
        <x-input  placeholder="请输入手机号"  title="手机号"></x-input>
        <x-input  placeholder="请输入验证码" title="验证码">
          <x-button slot="right" type="primary" mini>发送验证码</x-button>
          <x-input title="地址" placeholder="地址" ></x-input>
        </x-input>
      </group>
    </ul>
    <x-button class="submit" @click="sub(this)" type="primary">确认提交</x-button>
  </div>
</template>

<script>
  import '../assets/js/jquery-3.1.1.min.js'
  
  import axios from "axios";
  import navbar from "./navbar"
  import {Radio, Group, XNumber, XInput, XButton,Selector,Cell } from 'vux'
  
  export default {
    components: {
      navbar, Radio, Group, XNumber, XInput, XButton,Selector,Cell
    },
    name: 'Loading_machine',
    data() {
      return {
        list: [{key: 'gd', value: '广东'}, {key: 'gx', value: '广西'}],
      }
    },
    methods: {
      onChange (val) {
        console.log(val)
      },
      getValue (ref) {
        this.$vux.alert.show({
          title: 'getFullValue',
          content: this.$refs[ref].getFullValue()
        })
      }
    }
  }
</script>

<style scoped>
  input {
    display: inline-block;
    width: 1rem;
    height: 1rem;
    position: relative;
    top: 0.2rem;
    margin-right: .3rem;
  }
  a{
    text-decoration: none;
    color: #333333;
  }
  li {
    padding: 0 0.8rem;
    border-top: 1px solid #dddddd;
    line-height: 3rem;
  }
  
  li span {
    text-transform: uppercase;
    display: inline-block;
    margin-right: 0.6rem;
  }
  
  .submit {
    height: 2rem;
    margin-top: 2rem;
    width: 90%;
    line-height: 2rem;
    font-size: 0.8rem;
    color: #fff;
  }
</style>





















