<template>
  <div class="mywallet">
    <navbar>个人信息</navbar>
    <div class="content">
      <group label-width="5em">
        <cell class="infro" title="公司名称"  value-align="left"value="long lolong long"></cell>
        <cell  class="infro" title="地址" value-align="left" align-items="flex-start" value="long ong longlong long"></cell>
        <cell   class="infro" title="账号" value-align="left" align-items="flex-start" value="long ong longlong long"></cell>
        <cell  class="infro" title="联系方式" value-align="left" align-items="flex-start" value="long ong longlong long"></cell>
        
        <div class="blank"></div>
        <cell title="修改系统密码"   is-link  link=""></cell>
        <cell title="我的项目"   is-link  link="./myPro"></cell>
        <cell title="信息反馈"   is-link link="./feedback"></cell>
        <cell title="学习资料"   is-link  link="./studydata"></cell>
       
      </group>
  
      <x-button class="submit" @click="sub(this)" type="primary">退出登录</x-button>
    </div>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import {CellFormPreview, Group, Cell,XButton} from "vux"
  
  export default {
    components: {
      navbar,CellFormPreview, Group, Cell,XButton
    },
    name: 'personInfro',
    data() {
      return {
        msg: '的规范和你'
      }
    }
  }
</script>

<style scoped>
.submit{
  margin-top:2rem;
  height: 2rem;
  line-height: 2rem;
  width: 90%;
}

</style>
