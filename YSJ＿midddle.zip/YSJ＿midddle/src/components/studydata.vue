<template>
  <div >
    <navbar>学习资料</navbar>
    <div class="group">
      <group style="margin: 0;">
        <cell id="myPro" title="当啊当旺网络科技"></cell>
        <cell-form-preview :list="list"></cell-form-preview>
      </group>
      <!--<div class="blank"></div>-->
      <group>
        <cell title="当啊当旺网络科技" ></cell>
        <cell-form-preview :list="list"></cell-form-preview>
      </group>
    
    </div>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import { CellFormPreview, Group, Cell } from 'vux'
  
  export default {
    components: {
      navbar,CellFormPreview, Group, Cell
    },
    name: 'studydata',
    data() {
      return {
        list: [{
          label: 'Apple',
          value: '3.29'
        }, {
          label: 'Banana',
          value: '1.04'
        }, {
          label: 'Fish',
          value: '8.00'
        }, {
          label: 'Fish',
          value: '8.00'
        }]
      }
    }
  }
</script>

<style scoped>
  
  .group{
    background: #F2F2F2;
  }

</style>
