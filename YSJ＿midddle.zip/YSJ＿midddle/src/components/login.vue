<template>
  <div class="">
    <navbar>系统登录</navbar>
    <figure>
      <img src="../assets/images/index/icon_clock1@2x.png" alt="">
      <figcaption>
        <slot>饮水机管理系统</slot>
      </figcaption>
    </figure>
    
    <div class="nosubmit">
      <group>
        <x-input id="" type="text" placeholder="请输入账号" title="账号"></x-input>
        <x-input id="" type="password" placeholder="请输入密码" title="密码">
          <img src="../assets/images/index/dw.png" alt="">
          <img src="../assets/images/index/dw.png" alt="">
        </x-input>
      </group>
      <x-button class="submit" @click="sub(this)" type="primary">登陆</x-button>
    </div>
    
    <success class="submited"> 提交成功</success>
    <div class="tips"><p><img src="../assets/images/index/dw.png" alt="">还没有账号？请致电400 693 6818索要</p></div>
    <div class="supplay"><p>苏州智享环保科技有限公司</p></div>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar";  import success from "./success"
  import alert from "./alert"
  import {Group, Radio, XInput, XButton, XNumber, Alert} from "vux"
  
  export default {
    name: 'login',
    components: {
      navbar, Group, Radio, XInput, XButton, XNumber, Alert,success
    },
    data() {
      return {}
    },
    mounted() {
    
    },
    methods:{
      sub (obj){
        console.log(obj)
        $('.submited').show();
        $('.nosubmit').hide()
      }
    }
  }
</script>

<style scoped>
  .supplay{
    position: absolute;
    bottom: 3rem;
    color: #666666;
    text-align: center;
    width:100%;
  }
  .tips{
    color: #666666;
    text-align: center;
    margin-top: 4rem;
  }
  .tips img{
    width: 0.8rem;
    display: inline-block;
    margin-right:0.2rem;
  }
  figure {
    text-align: center;
    padding: 2rem 0;
  }
  
  figure img {
    width: 5rem;
    height: 5rem;
    margin-bottom: 1rem;
  }
  
  .submit {
    height: 2rem;
    margin-top: 2rem;
    width: 90%;
    line-height: 2rem;
    font-size: 0.8rem;
    color: #fff;
  }
  
  .submited {
    display: none;
  }
</style>
