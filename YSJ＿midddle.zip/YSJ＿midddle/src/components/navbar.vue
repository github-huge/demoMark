<template>
  <div class="">
    <header class="ffc">
      <a href="javascript:history.go(-1)">
        <div class="ds-in-bl">
          <img src="../assets/images/index/icon_back.png" alt="返回">
        </div>
      </a>
      <div class="ds-in-bl title">
        <div><span><slot>我的蜂巢</slot></span></div>
      </div>
      <div class="bar_right">
        <router-link to="./contractManger">
          <slot name="bar_right"></slot>
        </router-link>
      </div>
    </header>
  </div>
</template>

<script>
  export default {
    name: 'barnav',
    data() {
      return {
        msg: '的规范和你'
      }
    }
  }
</script>

<style scoped>
  header {
    background: #F4F4F4;
    padding: 0 0.6rem;
    line-height: 3rem;
  }
  
  .ds-in-bl img {
    width: 0.5rem;
  }
  
  .ds-in-bl {
    width: 5rem;
  }
  
  header .title {
    width: calc(100% - 9.2rem);
    text-align: center;
  }
  
  .bar_right {
    text-align: right;
  }
</style>
