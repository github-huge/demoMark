<template>
  <div class="">
     <figure>
       <img src="../assets/images/index/icon_clock1@2x.png" alt="">
       <figcaption><slot>提交成功</slot></figcaption>
     </figure>
  </div>
</template>

<script>
  export default {
    name: 'success',
    data () {
      return {
        msg: '的规范和你'
      }
    }
  }
</script>

<style scoped>
  figure{
    text-align: center;
    padding:2rem 0;
  }
  figure img{
    width: 3rem;
    height:3rem;
  }
</style>
