<template>
  <div class="mywallet">
    <navbar>填写设备信息</navbar>
    <group title="公司信息" class="devicetitle devicetitle01">
      <selector placeholder="请选择单位名称" v-model="demo01" title="单位名称" name="district" :options="list" ></selector>
      <selector placeholder="请选择联系地址" title="联系地址"  v-model="demo01" :options="list"></selector>
      <selector title="联系人" placeholder="请选择联系人"   v-model="demo01" :options="list"></selector>
      <selector title="联系电话" placeholder="请选择联系电话" v-model="demo01" :options="list"></selector>
      <x-input title="安装位置" placeholder="请填写"></x-input>
      <x-input title="覆盖人数" placeholder="请填写"></x-input>
      <x-input title="安装人" placeholder="请填写"></x-input>
      <x-input title="天数/升数" placeholder="请填写"></x-input>
    </group>
    
    <group title="设备信息" class="devicetitle">
      <selector title="设备型号" placeholder="请选择设备型号" v-model="demo01" :options="list"></selector>
      <selector title="计费类型" placeholder="请选择计费类型" v-model="demo01" :options="list"></selector>
      <x-input title="源水DTS" placeholder="请填写源水DTS"></x-input>
      <x-input title="源水压力" placeholder="请填写源水压力"></x-input>
      <selector title="废水比例" placeholder="请选择废水比例" v-model="demo01" :options="list"></selector>
      <selector title="开机时间" placeholder="请选择开机时间" v-model="demo01" :options="list"></selector>
      <selector title="关机时间" placeholder="请选择关机时间" v-model="demo01" :options="list"></selector>
      <selector title="安装日期" placeholder="请选择安装日期" v-model="demo01" :options="list"></selector>
      <x-input title="安装人" placeholder="请填写安装日期"></x-input>
      <x-input title="安装人电话" placeholder="请填写"></x-input>
    </group>
    <x-button class="submit" @click="sub(this)" type="primary">提交</x-button>
  </div>
</template>

<script>
  import axios from "axios";
  import navbar from "./navbar"
  import {Selector ,Group, Cell,XInput,XButton} from "vux"
  
  export default {
    components: {
      navbar,Group, Cell,Selector,XInput,XButton
    },
    name: 'deviceInfro',
    data() {
      return {
        demo01: null,
        list: [{key: 'gd', value: '广东'}, {key: 'gx', value: '广西'}],
      }
    },
    methods: {
      onChange (val) {
        console.log(val)
      },
      getValue (ref) {
        this.$vux.alert.show({
          title: 'getFullValue',
          content: this.$refs[ref].getFullValue()
        })
      }
    }
  }
</script>

<style scoped>

.submit{
  height:2rem;
  line-height: 2rem;
  width: 90%;
  margin:1rem auto;
}
</style>
