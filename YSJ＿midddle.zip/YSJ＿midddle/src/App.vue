<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
  import axios from "axios";
  
  import { XInput,XButton ,Group,XTextarea ,Cell,XNumber, Box, GroupTitle, Flexbox, FlexboxItem, Divider,Datetime, Search  } from 'vux'
export default {
  name: 'app',
  components: {
    XInput,XButton,XNumber,XTextarea, Group,Cell, Box, GroupTitle, Flexbox, FlexboxItem,Datetime , Divider,  Search,
  },
}
</script>

<style lang="less">
@import '~vux/src/styles/reset.less';
.devicetitle01.devicetitle .weui-cells__title{
  border-top: 1px solid #dddddd;
}

.devicetitle  .weui-cells__title{
  background: #F4F4F4;
  line-height:3rem;
  margin:0;
}
a{
  color: #333333;
}
.vux-no-group-title{
  margin-top: 0!important;
  font-size: 0.8rem;
}
.vux-label{
    display: inline!important;
    width:6rem;
  }
#myPro .vux-cell-bd p{
  width:100%;
}
.facilityNum .vux-cell-primary div{
  height: 2rem;
}

.facilityNum .vux-cell-primary div a, .facilityNum .vux-cell-primary div input{
  height: 2rem;
  line-height:2rem;
}
.facilityNum .vux-cell-primary  div .vux-number-selector-sub{
  line-height:1.5rem;
}

.facilityNum .vux-cell-primary  div  .vux-number-selector-plus{
    padding:0 0.33rem ;
  }
.weui-cell:before{
  border-top: none;
}

.infro .vux-cell-bd{
  margin-right: 0.5rem;
}
</style>
